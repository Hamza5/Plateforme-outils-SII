function display(CPD)

disp('gaussian_CPD object');
disp(struct(CPD)); 
