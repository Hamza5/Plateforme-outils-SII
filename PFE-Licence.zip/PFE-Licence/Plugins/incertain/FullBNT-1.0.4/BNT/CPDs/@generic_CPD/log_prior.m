function L = log_prior(CPD)
% LOG_PRIOR Return log P(theta) for a generic CPD  - we return 0
% L = log_prior(CPD)

L = 0;
