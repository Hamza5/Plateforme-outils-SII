function CPT = CPD_to_CPT(CPD)
% CPD_TO_CPT Convert the tabular_decision_node to a CPT
% CPT = CPD_to_CPT(CPD)

CPT = CPD.CPT;
