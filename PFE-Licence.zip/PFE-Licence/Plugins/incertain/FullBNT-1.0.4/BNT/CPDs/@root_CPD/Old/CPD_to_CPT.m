function CPT = CPD_to_CPT(CPD)
% CPD_TO_CPT Convert the CPD to tabular form (root)
% CPT = CPD_to_CPT(CPD)

CPT = 1;
